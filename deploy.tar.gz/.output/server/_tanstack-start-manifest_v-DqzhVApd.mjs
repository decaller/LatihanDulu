const tsrStartManifest = () => ({ routes: { __root__: { filePath: "/home/abuhafi/Project/TesDeen/src/routes/__root.tsx", children: ["/", "/semua"], assets: void 0, preloads: ["/assets/index-BOwmM9A5.js"] }, "/": { filePath: "/home/abuhafi/Project/TesDeen/src/routes/index.tsx", children: void 0, assets: void 0, preloads: ["/assets/index-CiaPto-Z.js", "/assets/button-C7lTW0D3.js"] }, "/semua": { filePath: "/home/abuhafi/Project/TesDeen/src/routes/semua.tsx", children: void 0, assets: void 0, preloads: ["/assets/semua-8EaystLz.js", "/assets/button-C7lTW0D3.js"] } }, clientEntry: "/assets/index-BOwmM9A5.js" });
export {
  tsrStartManifest
};
