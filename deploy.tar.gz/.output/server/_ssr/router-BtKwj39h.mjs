import { b as createRouter, a as createRootRoute, c as createFileRoute, l as lazyRouteComponent, H as HeadContent, S as Scripts } from "../_libs/tanstack__react-router.mjs";
import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { c as createServerFn, T as TSS_SERVER_FUNCTION, g as getServerFnById } from "./index.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:stream/promises";
import "node:https";
import "node:http2";
const appCss = "/assets/styles-4S0Xku9d.css";
const Route$2 = createRootRoute({
  head: () => ({
    meta: [
      {
        charSet: "utf-8"
      },
      {
        name: "viewport",
        content: "width=device-width, initial-scale=1"
      },
      {
        title: "LatihanDulu"
      }
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss
      }
    ]
  }),
  notFoundComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "container mx-auto p-4 pt-16", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { children: "404" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "The requested page could not be found." })
  ] }),
  shellComponent: RootDocument
});
function RootDocument({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("head", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Scripts, {})
    ] })
  ] });
}
var createSsrRpc = (functionId) => {
  const url = "/_serverFn/" + functionId;
  const serverFnMeta = { id: functionId };
  const fn = async (...args) => {
    return (await getServerFnById(functionId))(...args);
  };
  return Object.assign(fn, {
    url,
    serverFnMeta,
    [TSS_SERVER_FUNCTION]: true
  });
};
const $$splitComponentImporter$1 = () => import("./semua-_ro_g_Qa.mjs");
const getQuizDataFn = createServerFn({
  method: "GET"
}).handler(createSsrRpc("eef8a9d204cb7b494f929c8194b2aa79c72ae8c66c7d41e06d97eb253cb311a0"));
const softDeleteQuestionFnBase = createServerFn({
  method: "POST"
}).handler(createSsrRpc("201e31e2aab9ea3d07178d1fe859c483ac65daae99d4a6f6ae9fc1dd25b88882"));
const softDeleteQuestionFn = softDeleteQuestionFnBase;
const restoreQuestionFnBase = createServerFn({
  method: "POST"
}).handler(createSsrRpc("3fa2a94e52708b29eccfcad587b15e19b09d8385635cc31df01c05c2618e13e5"));
const restoreQuestionFn = restoreQuestionFnBase;
const hardDeleteQuestionFnBase = createServerFn({
  method: "POST"
}).handler(createSsrRpc("83f9058aad227d3442c8df762584f0fa8cec7cd76f64e7387b9fb40313c7697e"));
const hardDeleteQuestionFn = hardDeleteQuestionFnBase;
const flagQuestionFnBase = createServerFn({
  method: "POST"
}).handler(createSsrRpc("1ed9d302e43fca6971134a7197a70257507cd7173ddd35229f6728ebe7b7193e"));
const flagQuestionFn = flagQuestionFnBase;
const resolveQuestionFnBase = createServerFn({
  method: "POST"
}).handler(createSsrRpc("8a320d16c307fbf97b773a823aa9b5aa6996ab3959dcc6caf2c393d55b9b715e"));
const resolveQuestionFn = resolveQuestionFnBase;
const toggleCheckedStatusFnBase = createServerFn({
  method: "POST"
}).handler(createSsrRpc("09bfc20df8ce0b6270afcefd2f9b210b1b96b1170ec705c569256015af26a76c"));
const toggleCheckedStatusFn = toggleCheckedStatusFnBase;
const Route$1 = createFileRoute("/semua")({
  loader: async () => {
    return await getQuizDataFn();
  },
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const $$splitComponentImporter = () => import("./index-Ohid1rPZ.mjs");
const Route = createFileRoute("/")({
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const SemuaRoute = Route$1.update({
  id: "/semua",
  path: "/semua",
  getParentRoute: () => Route$2
});
const IndexRoute = Route.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$2
});
const rootRouteChildren = {
  IndexRoute,
  SemuaRoute
};
const routeTree = Route$2._addFileChildren(rootRouteChildren)._addFileTypes();
function getRouter() {
  const router2 = createRouter({
    routeTree,
    scrollRestoration: true,
    defaultPreload: "intent",
    defaultPreloadStaleTime: 0
  });
  return router2;
}
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  Route$1 as R,
  restoreQuestionFn as a,
  router as b,
  flagQuestionFn as f,
  hardDeleteQuestionFn as h,
  resolveQuestionFn as r,
  softDeleteQuestionFn as s,
  toggleCheckedStatusFn as t
};
