import { T as TSS_SERVER_FUNCTION, c as createServerFn } from "./index.mjs";
import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:stream";
import "node:stream/promises";
import "node:https";
import "node:http2";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
var createServerRpc = (serverFnMeta, splitImportFn) => {
  const url = "/_serverFn/" + serverFnMeta.id;
  return Object.assign(splitImportFn, {
    url,
    serverFnMeta,
    [TSS_SERVER_FUNCTION]: true
  });
};
const getQuizDataFn_createServerFn_handler = createServerRpc({
  id: "eef8a9d204cb7b494f929c8194b2aa79c72ae8c66c7d41e06d97eb253cb311a0",
  name: "getQuizDataFn",
  filename: "src/routes/semua.tsx"
}, (opts) => getQuizDataFn.__executeServer(opts));
const getQuizDataFn = createServerFn({
  method: "GET"
}).handler(getQuizDataFn_createServerFn_handler, async () => {
  const {
    Database
  } = await import("bun:sqlite");
  const dbPath = process.env.DB_PATH && process.env.DB_PATH.startsWith("/") ? process.env.DB_PATH : `${process.cwd()}/${process.env.DB_PATH || "backend/data.db"}`;
  const db = new Database(dbPath);
  try {
    const rawQuestions = db.query(`
      SELECT 
        q.id,
        q.article_id,
        q.question_text,
        q.option_a,
        q.option_b,
        q.option_c,
        q.option_d,
        q.correct_option,
        q.explanation,
        q.deleted_at,
        q.flagged_reason,
        q.flagged_notes,
        q.flagged_at,
        q.created_by_model,
        q.created_on_device,
        q.updated_by_model,
        q.updated_on_device,
        q.updated_at,
        q.checked_status,
        q.reference_snippet,
        a.title AS article_title,
        a.url AS article_url,
        a.silsilah AS article_silsilah,
        a.speaker AS article_speaker
      FROM questions q
      JOIN articles a ON q.article_id = a.id
    `).all();
    const hierarchyRows = db.query("SELECT parent_url, child_url, title FROM hierarchy").all();
    const articleRows = db.query("SELECT id, url, title FROM articles").all();
    const childToParentMap = /* @__PURE__ */ new Map();
    for (const row of hierarchyRows) {
      if (row.child_url) {
        childToParentMap.set(row.child_url.trim().replace(/\/$/, ""), {
          parent_url: row.parent_url.trim().replace(/\/$/, ""),
          title: row.title
        });
      }
    }
    const articleUrlToTitleMap = /* @__PURE__ */ new Map();
    for (const row of articleRows) {
      if (row.url) {
        articleUrlToTitleMap.set(row.url.trim().replace(/\/$/, ""), row.title);
      }
    }
    const getBreadcrumbs = (url) => {
      const crumbs = [];
      let currentUrl = url.trim().replace(/\/$/, "");
      const visited = /* @__PURE__ */ new Set();
      while (currentUrl && !visited.has(currentUrl)) {
        visited.add(currentUrl);
        const parentInfo = childToParentMap.get(currentUrl);
        if (!parentInfo) {
          const title = articleUrlToTitleMap.get(currentUrl) || currentUrl;
          crumbs.unshift({
            title,
            url: currentUrl
          });
          break;
        }
        crumbs.unshift({
          title: parentInfo.title || articleUrlToTitleMap.get(currentUrl) || currentUrl,
          url: currentUrl
        });
        currentUrl = parentInfo.parent_url;
      }
      crumbs.unshift({
        title: "Mulai (Root)",
        url: "https://ilmiyyah.com"
      });
      return crumbs;
    };
    const questions = rawQuestions.map((q) => ({
      ...q,
      deleted_at: q.deleted_at === "NULL" || !q.deleted_at ? null : q.deleted_at,
      flagged_reason: q.flagged_reason === "NULL" || !q.flagged_reason ? null : q.flagged_reason,
      flagged_notes: q.flagged_notes === "NULL" || !q.flagged_notes ? null : q.flagged_notes,
      flagged_at: q.flagged_at === "NULL" || !q.flagged_at ? null : q.flagged_at,
      created_by_model: q.created_by_model === "NULL" || !q.created_by_model ? "Gemini 2.5 Flash" : q.created_by_model,
      created_on_device: q.created_on_device === "NULL" || !q.created_on_device ? "Server-Prod-01" : q.created_on_device,
      updated_by_model: q.updated_by_model === "NULL" || !q.updated_by_model ? null : q.updated_by_model,
      updated_on_device: q.updated_on_device === "NULL" || !q.updated_on_device ? null : q.updated_on_device,
      updated_at: q.updated_at === "NULL" || !q.updated_at ? null : q.updated_at,
      checked_status: q.checked_status === "NULL" || !q.checked_status ? "buatan AI" : q.checked_status,
      reference_snippet: q.reference_snippet === "NULL" || !q.reference_snippet ? null : q.reference_snippet,
      breadcrumbs: getBreadcrumbs(q.article_url)
    }));
    const activeQuestions = questions.filter((q) => !q.deleted_at);
    const deletedQuestions = questions.filter((q) => q.deleted_at);
    return {
      questions,
      stats: {
        totalQuestions: activeQuestions.length,
        totalDeletedQuestions: deletedQuestions.length,
        totalFlaggedQuestions: activeQuestions.filter((q) => q.flagged_reason).length,
        totalArticlesWithQuestions: new Set(activeQuestions.map((q) => q.article_id)).size,
        totalDatabaseArticles: articleRows.length
      }
    };
  } catch (error) {
    console.error("Database query failed:", error);
    throw new Error("Failed to load database: " + error.message);
  } finally {
    db.close();
  }
});
const softDeleteQuestionFnBase_createServerFn_handler = createServerRpc({
  id: "201e31e2aab9ea3d07178d1fe859c483ac65daae99d4a6f6ae9fc1dd25b88882",
  name: "softDeleteQuestionFnBase",
  filename: "src/routes/semua.tsx"
}, (opts) => softDeleteQuestionFnBase.__executeServer(opts));
const softDeleteQuestionFnBase = createServerFn({
  method: "POST"
}).handler(softDeleteQuestionFnBase_createServerFn_handler, async (ctx) => {
  const id = ctx.data;
  const {
    Database
  } = await import("bun:sqlite");
  const dbPath = process.env.DB_PATH && process.env.DB_PATH.startsWith("/") ? process.env.DB_PATH : `${process.cwd()}/${process.env.DB_PATH || "backend/data.db"}`;
  const db = new Database(dbPath);
  try {
    db.query(`
        UPDATE questions 
        SET deleted_at = CURRENT_TIMESTAMP,
            updated_by_model = 'User Moderator (Soft Deleted)',
            updated_on_device = 'Local Computer',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(id);
    return {
      success: true
    };
  } catch (error) {
    console.error("Soft delete failed:", error);
    throw new Error("Failed to soft delete question: " + error.message);
  } finally {
    db.close();
  }
});
const restoreQuestionFnBase_createServerFn_handler = createServerRpc({
  id: "3fa2a94e52708b29eccfcad587b15e19b09d8385635cc31df01c05c2618e13e5",
  name: "restoreQuestionFnBase",
  filename: "src/routes/semua.tsx"
}, (opts) => restoreQuestionFnBase.__executeServer(opts));
const restoreQuestionFnBase = createServerFn({
  method: "POST"
}).handler(restoreQuestionFnBase_createServerFn_handler, async (ctx) => {
  const id = ctx.data;
  const {
    Database
  } = await import("bun:sqlite");
  const dbPath = process.env.DB_PATH && process.env.DB_PATH.startsWith("/") ? process.env.DB_PATH : `${process.cwd()}/${process.env.DB_PATH || "backend/data.db"}`;
  const db = new Database(dbPath);
  try {
    db.query(`
        UPDATE questions 
        SET deleted_at = NULL,
            updated_by_model = 'User Moderator (Restored)',
            updated_on_device = 'Local Computer',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(id);
    return {
      success: true
    };
  } catch (error) {
    console.error("Restore failed:", error);
    throw new Error("Failed to restore question: " + error.message);
  } finally {
    db.close();
  }
});
const hardDeleteQuestionFnBase_createServerFn_handler = createServerRpc({
  id: "83f9058aad227d3442c8df762584f0fa8cec7cd76f64e7387b9fb40313c7697e",
  name: "hardDeleteQuestionFnBase",
  filename: "src/routes/semua.tsx"
}, (opts) => hardDeleteQuestionFnBase.__executeServer(opts));
const hardDeleteQuestionFnBase = createServerFn({
  method: "POST"
}).handler(hardDeleteQuestionFnBase_createServerFn_handler, async (ctx) => {
  const id = ctx.data;
  const {
    Database
  } = await import("bun:sqlite");
  const dbPath = process.env.DB_PATH && process.env.DB_PATH.startsWith("/") ? process.env.DB_PATH : `${process.cwd()}/${process.env.DB_PATH || "backend/data.db"}`;
  const db = new Database(dbPath);
  try {
    db.query("DELETE FROM questions WHERE id = ?").run(id);
    return {
      success: true
    };
  } catch (error) {
    console.error("Hard delete failed:", error);
    throw new Error("Failed to permanently delete question: " + error.message);
  } finally {
    db.close();
  }
});
const flagQuestionFnBase_createServerFn_handler = createServerRpc({
  id: "1ed9d302e43fca6971134a7197a70257507cd7173ddd35229f6728ebe7b7193e",
  name: "flagQuestionFnBase",
  filename: "src/routes/semua.tsx"
}, (opts) => flagQuestionFnBase.__executeServer(opts));
const flagQuestionFnBase = createServerFn({
  method: "POST"
}).handler(flagQuestionFnBase_createServerFn_handler, async (ctx) => {
  const {
    id,
    reason,
    notes
  } = ctx.data;
  const {
    Database
  } = await import("bun:sqlite");
  const dbPath = process.env.DB_PATH && process.env.DB_PATH.startsWith("/") ? process.env.DB_PATH : `${process.cwd()}/${process.env.DB_PATH || "backend/data.db"}`;
  const db = new Database(dbPath);
  try {
    db.query(`
        UPDATE questions 
        SET flagged_reason = ?, 
            flagged_notes = ?, 
            flagged_at = CURRENT_TIMESTAMP,
            updated_by_model = 'User Moderator',
            updated_on_device = 'Local Computer',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(reason, notes, id);
    return {
      success: true
    };
  } catch (error) {
    console.error("Flag question failed:", error);
    throw new Error("Failed to flag question: " + error.message);
  } finally {
    db.close();
  }
});
const resolveQuestionFnBase_createServerFn_handler = createServerRpc({
  id: "8a320d16c307fbf97b773a823aa9b5aa6996ab3959dcc6caf2c393d55b9b715e",
  name: "resolveQuestionFnBase",
  filename: "src/routes/semua.tsx"
}, (opts) => resolveQuestionFnBase.__executeServer(opts));
const resolveQuestionFnBase = createServerFn({
  method: "POST"
}).handler(resolveQuestionFnBase_createServerFn_handler, async (ctx) => {
  const id = ctx.data;
  const {
    Database
  } = await import("bun:sqlite");
  const dbPath = process.env.DB_PATH && process.env.DB_PATH.startsWith("/") ? process.env.DB_PATH : `${process.cwd()}/${process.env.DB_PATH || "backend/data.db"}`;
  const db = new Database(dbPath);
  try {
    db.query(`
        UPDATE questions 
        SET flagged_reason = NULL, 
            flagged_notes = NULL, 
            flagged_at = NULL,
            updated_by_model = 'User Moderator (Resolved)',
            updated_on_device = 'Local Computer',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(id);
    return {
      success: true
    };
  } catch (error) {
    console.error("Resolve flag failed:", error);
    throw new Error("Failed to resolve flag: " + error.message);
  } finally {
    db.close();
  }
});
const toggleCheckedStatusFnBase_createServerFn_handler = createServerRpc({
  id: "09bfc20df8ce0b6270afcefd2f9b210b1b96b1170ec705c569256015af26a76c",
  name: "toggleCheckedStatusFnBase",
  filename: "src/routes/semua.tsx"
}, (opts) => toggleCheckedStatusFnBase.__executeServer(opts));
const toggleCheckedStatusFnBase = createServerFn({
  method: "POST"
}).handler(toggleCheckedStatusFnBase_createServerFn_handler, async (ctx) => {
  const {
    id,
    status
  } = ctx.data;
  const {
    Database
  } = await import("bun:sqlite");
  const dbPath = process.env.DB_PATH && process.env.DB_PATH.startsWith("/") ? process.env.DB_PATH : `${process.cwd()}/${process.env.DB_PATH || "backend/data.db"}`;
  const db = new Database(dbPath);
  try {
    db.query(`
        UPDATE questions 
        SET checked_status = ?,
            updated_by_model = 'User Moderator',
            updated_on_device = 'Local Computer',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(status, id);
    return {
      success: true
    };
  } catch (error) {
    console.error("Toggle checked status failed:", error);
    throw new Error("Failed to update checked status: " + error.message);
  } finally {
    db.close();
  }
});
export {
  flagQuestionFnBase_createServerFn_handler,
  getQuizDataFn_createServerFn_handler,
  hardDeleteQuestionFnBase_createServerFn_handler,
  resolveQuestionFnBase_createServerFn_handler,
  restoreQuestionFnBase_createServerFn_handler,
  softDeleteQuestionFnBase_createServerFn_handler,
  toggleCheckedStatusFnBase_createServerFn_handler
};
