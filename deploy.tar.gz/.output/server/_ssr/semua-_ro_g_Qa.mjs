import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { u as useRouter } from "../_libs/tanstack__react-router.mjs";
import { B as Button } from "./button-DLuSCGEG.mjs";
import { O as OA, $ as $C, M as M6, v as vi, c as c4, h as hs, p as pv, P as P7, f as f1, x as xi, J as J1, b as ba, u as uo, y, r as r2, Q as QM, s as s7, i as i2, a as xs } from "../_libs/remixicon__react.mjs";
import { R as Route$1, t as toggleCheckedStatusFn, s as softDeleteQuestionFn, a as restoreQuestionFn, h as hardDeleteQuestionFn, r as resolveQuestionFn, f as flagQuestionFn } from "./router-BtKwj39h.mjs";
import "./index.mjs";
import "../_libs/seroval.mjs";
import { A as AnimatePresence, m as motion } from "../_libs/framer-motion.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:stream/promises";
import "node:https";
import "node:http2";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
function HierarchyFolderTree({
  node,
  activeFilter,
  onSelectNode,
  expandedNodes,
  toggleExpand
}) {
  const isExpanded = expandedNodes.has(node.url);
  const isSelected = activeFilter === node.url;
  const hasChildren = node.children.size > 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pl-3 select-none", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `group flex cursor-pointer items-center gap-1.5 rounded-md px-2 py-1 text-xs transition-all ${isSelected ? "border border-primary/20 bg-primary/10 font-medium text-primary" : "border border-transparent text-muted-foreground hover:bg-muted hover:text-foreground"}`, onClick: () => onSelectNode(node.url === "https://ilmiyyah.com" ? null : node.url), children: [
      hasChildren ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded p-0.5 transition-colors hover:bg-muted-foreground/10", onClick: (e) => {
        e.stopPropagation();
        toggleExpand(node.url);
      }, children: isExpanded ? /* @__PURE__ */ jsxRuntimeExports.jsx(f1, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(r2, { className: "h-3.5 w-3.5" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-4" }),
      hasChildren ? isExpanded ? /* @__PURE__ */ jsxRuntimeExports.jsx(xs, { className: "h-3.5 w-3.5 shrink-0 text-primary" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(hs, { className: "h-3.5 w-3.5 shrink-0 text-muted-foreground/80" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(c4, { className: "h-3.5 w-3.5 shrink-0 text-primary/80" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "max-w-[180px] truncate font-sans", title: node.title, children: node.title })
    ] }),
    hasChildren && isExpanded && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "animate-fadeIn mt-0.5 ml-2 space-y-0.5 border-l border-muted pl-1", children: Array.from(node.children.values()).map((child) => /* @__PURE__ */ jsxRuntimeExports.jsx(HierarchyFolderTree, { node: child, activeFilter, onSelectNode, expandedNodes, toggleExpand }, child.url)) })
  ] });
}
function SemuaDashboard() {
  const {
    questions,
    stats
  } = Route$1.useLoaderData();
  const router = useRouter();
  const [searchTerm, setSearchTerm] = reactExports.useState("");
  const [activeFilterUrl, setActiveFilterUrl] = reactExports.useState(null);
  const [selectedQuestion, setSelectedQuestion] = reactExports.useState(null);
  const [expandedNodes, setExpandedNodes] = reactExports.useState(/* @__PURE__ */ new Set(["https://ilmiyyah.com"]));
  const [viewTab, setViewTab] = reactExports.useState("active");
  const [isFilterModalOpen, setIsFilterModalOpen] = reactExports.useState(false);
  const [isFlagModalOpen, setIsFlagModalOpen] = reactExports.useState(false);
  const [flagReason, setFlagReason] = reactExports.useState("Pertanyaan tidak jelas/bias");
  const [flagNotes, setFlagNotes] = reactExports.useState("");
  const [deleteConfirmId, setDeleteConfirmId] = reactExports.useState(null);
  const [selectedModel, setSelectedModel] = reactExports.useState(null);
  const modelsList = reactExports.useMemo(() => {
    const list = /* @__PURE__ */ new Set();
    for (const q of questions) {
      list.add(q.created_by_model || "Gemini 2.5 Flash");
    }
    return Array.from(list);
  }, [questions]);
  reactExports.useEffect(() => {
    if (selectedQuestion) {
      const fresh = questions.find((q) => q.id === selectedQuestion.id);
      if (fresh) {
        setSelectedQuestion(fresh);
      } else {
        setSelectedQuestion(null);
      }
    }
  }, [questions]);
  reactExports.useEffect(() => {
    if (!deleteConfirmId) return;
    const handleOutsideClick = (e) => {
      const target = e.target;
      if (!target.closest(".delete-popover-container") && !target.closest("button")) {
        setDeleteConfirmId(null);
      }
    };
    document.addEventListener("click", handleOutsideClick);
    return () => document.removeEventListener("click", handleOutsideClick);
  }, [deleteConfirmId]);
  const closeInspector = () => {
    setSelectedQuestion(null);
    setFlagReason("Pertanyaan tidak jelas/bias");
    setFlagNotes("");
  };
  const folderTree = reactExports.useMemo(() => {
    const root = {
      title: "Mulai (Root)",
      url: "https://ilmiyyah.com",
      children: /* @__PURE__ */ new Map(),
      isLeaf: false
    };
    const targetQuestions = questions.filter((q) => {
      if (viewTab === "active") return !q.deleted_at;
      if (viewTab === "deleted") return !!q.deleted_at;
      return !q.deleted_at && !!q.flagged_reason;
    });
    for (const q of targetQuestions) {
      let current = root;
      for (let i = 1; i < q.breadcrumbs.length; i++) {
        const crumb = q.breadcrumbs[i];
        const cleanUrl = crumb.url.trim().replace(/\/$/, "");
        if (!current.children.has(cleanUrl)) {
          current.children.set(cleanUrl, {
            title: crumb.title,
            url: cleanUrl,
            children: /* @__PURE__ */ new Map(),
            isLeaf: i === q.breadcrumbs.length - 1,
            articleId: i === q.breadcrumbs.length - 1 ? q.article_id : void 0
          });
        }
        current = current.children.get(cleanUrl);
      }
    }
    return root;
  }, [questions, viewTab]);
  const toggleExpand = (url) => {
    const next = new Set(expandedNodes);
    if (next.has(url)) {
      next.delete(url);
    } else {
      next.add(url);
    }
    setExpandedNodes(next);
  };
  const filteredQuestions = reactExports.useMemo(() => {
    return questions.filter((q) => {
      let matchesTab = false;
      if (viewTab === "active") {
        matchesTab = !q.deleted_at;
      } else if (viewTab === "deleted") {
        matchesTab = !!q.deleted_at;
      } else if (viewTab === "flagged") {
        matchesTab = !q.deleted_at && !!q.flagged_reason;
      }
      if (!matchesTab) return false;
      const query = searchTerm.toLowerCase().trim();
      const matchesSearch = query === "" || q.question_text.toLowerCase().includes(query) || q.option_a.toLowerCase().includes(query) || q.option_b.toLowerCase().includes(query) || q.option_c.toLowerCase().includes(query) || q.option_d.toLowerCase().includes(query) || q.explanation.toLowerCase().includes(query) || q.article_title.toLowerCase().includes(query);
      const matchesHierarchy = !activeFilterUrl || q.breadcrumbs.some((crumb) => crumb.url.trim().replace(/\/$/, "") === activeFilterUrl.trim().replace(/\/$/, ""));
      const matchesModel = !selectedModel || (q.created_by_model || "Gemini 2.5 Flash") === selectedModel;
      return matchesSearch && matchesHierarchy && matchesModel;
    });
  }, [questions, searchTerm, activeFilterUrl, viewTab, selectedModel]);
  const [currentPage, setCurrentPage] = reactExports.useState(1);
  const itemsPerPage = 10;
  const paginatedQuestions = reactExports.useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredQuestions.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredQuestions, currentPage]);
  reactExports.useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, activeFilterUrl, viewTab, selectedModel]);
  const currentCategoryName = reactExports.useMemo(() => {
    if (!activeFilterUrl) return "Semua Materi";
    if (activeFilterUrl === "https://ilmiyyah.com") return "Mulai (Root)";
    for (const q of questions) {
      const crumb = q.breadcrumbs.find((c) => c.url.trim().replace(/\/$/, "") === activeFilterUrl.trim().replace(/\/$/, ""));
      if (crumb) return crumb.title;
    }
    return activeFilterUrl;
  }, [activeFilterUrl, questions]);
  const currentIndex = reactExports.useMemo(() => {
    if (!selectedQuestion) return -1;
    return filteredQuestions.findIndex((q) => q.id === selectedQuestion.id);
  }, [selectedQuestion, filteredQuestions]);
  const hasPrevious = currentIndex > 0;
  const hasNext = currentIndex !== -1 && currentIndex < filteredQuestions.length - 1;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex min-h-screen flex-col bg-background font-sans text-foreground antialiased", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "sticky top-0 z-40 border-b border-border bg-background/85 px-6 py-4 backdrop-blur-md", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto flex max-w-7xl flex-col gap-4 md:flex-row md:items-center md:justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-xl border border-primary/20 bg-primary/10 p-2.5 text-primary", children: /* @__PURE__ */ jsxRuntimeExports.jsx(OA, { className: "h-6 w-6 animate-pulse" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-lg font-semibold tracking-tight", children: "Bismillah. Analisis Soal" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Portal evaluasi terpadu materi kajian Ilmiyyah" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => {
          setViewTab("active");
          setActiveFilterUrl(null);
        }, className: `flex cursor-pointer items-center gap-2.5 rounded-lg border px-3 py-1.5 text-xs shadow-xs transition-all ${viewTab === "active" ? "border-primary/20 bg-primary/10 font-semibold text-primary" : "border-border bg-card text-card-foreground hover:bg-muted"}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx($C, { className: "h-4 w-4 text-primary" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold", children: stats.totalQuestions }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-1 text-muted-foreground", children: "Soal Aktif" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => {
          setViewTab("deleted");
          setActiveFilterUrl(null);
        }, className: `flex cursor-pointer items-center gap-2.5 rounded-lg border px-3 py-1.5 text-xs shadow-xs transition-all ${viewTab === "deleted" ? "border-amber-500/20 bg-amber-500/10 font-semibold text-amber-600" : "border-border bg-card text-card-foreground hover:bg-muted"}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(M6, { className: "h-4 w-4 text-amber-500" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold", children: stats.totalDeletedQuestions || 0 }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-1 text-muted-foreground", children: "Sampah" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => {
          setViewTab("flagged");
          setActiveFilterUrl(null);
        }, className: `flex cursor-pointer items-center gap-2.5 rounded-lg border px-3 py-1.5 text-xs shadow-xs transition-all ${viewTab === "flagged" ? "border-red-500/20 bg-red-500/10 font-semibold text-red-600" : "border-border bg-card text-card-foreground hover:bg-muted"}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(vi, { className: "h-4 w-4 text-red-500" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold", children: stats.totalFlaggedQuestions || 0 }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-1 text-muted-foreground", children: "Ditandai (Flag)" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 rounded-lg border border-border bg-card px-3 py-1.5 text-card-foreground shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(c4, { className: "h-4 w-4 text-emerald-600" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: stats.totalArticlesWithQuestions }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-1 text-muted-foreground", children: "Kajian Terbit" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 rounded-lg border border-border bg-card px-3 py-1.5 text-card-foreground shadow-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(hs, { className: "h-4 w-4 text-amber-500" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: stats.totalDatabaseArticles }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-1 text-muted-foreground", children: "Total Transkrip" })
          ] })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto flex w-full max-w-7xl flex-1 flex-col gap-6 p-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "flex min-w-0 flex-1 flex-col gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-3 rounded-xl border border-border bg-card p-3 shadow-2xs sm:flex-row sm:items-center sm:justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-3 sm:flex-row sm:items-center flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(pv, { className: "absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "text", placeholder: "Cari kata kunci soal, artikel, opsi, atau penjelasan...", value: searchTerm, onChange: (e) => setSearchTerm(e.target.value), className: "w-full rounded-lg border border-border bg-background py-1.5 pr-8 pl-9 text-sm text-ellipsis transition-all focus:border-primary focus:ring-1 focus:ring-primary focus:outline-none" }),
            searchTerm && /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setSearchTerm(""), className: "absolute top-1/2 right-2.5 -translate-y-1/2 rounded-full p-0.5 text-muted-foreground transition-all hover:bg-muted", children: /* @__PURE__ */ jsxRuntimeExports.jsx(P7, { className: "h-3.5 w-3.5" }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: () => setIsFilterModalOpen(true), className: "flex items-center gap-1.5 rounded-lg border border-border bg-card px-3.5 py-1.5 text-xs font-semibold text-foreground hover:bg-muted cursor-pointer shadow-3xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(hs, { className: "h-4 w-4 text-primary shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Pilih Silsilah / Materi" })
            ] }),
            activeFilterUrl && /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setActiveFilterUrl(null), className: "rounded bg-muted px-2 py-1 text-[10px] text-muted-foreground transition-all hover:bg-muted-foreground/15 cursor-pointer font-medium", children: "Reset Filter" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { value: selectedModel || "", onChange: (e) => setSelectedModel(e.target.value || null), className: "appearance-none rounded-lg border border-border bg-card py-1.5 pl-8 pr-8 text-xs font-semibold text-foreground hover:bg-muted focus:outline-none focus:ring-1 focus:ring-primary cursor-pointer shadow-3xs", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "Semua Model AI" }),
                modelsList.map((m) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: m, children: m }, m))
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(OA, { className: "absolute top-1/2 left-2.5 h-3.5 w-3.5 -translate-y-1/2 text-primary shrink-0 pointer-events-none" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(f1, { className: "absolute top-1/2 right-2 h-4 w-4 -translate-y-1/2 text-muted-foreground shrink-0 pointer-events-none" })
            ] }),
            selectedModel && /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setSelectedModel(null), className: "rounded bg-muted px-2 py-1 text-[10px] text-muted-foreground transition-all hover:bg-muted-foreground/15 cursor-pointer font-medium", children: "Reset Model" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex shrink-0 items-center gap-2 self-start text-xs sm:self-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Menampilkan:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "max-w-[150px] truncate rounded-md border border-primary/20 bg-primary/10 px-2 py-0.5 font-semibold text-primary", title: currentCategoryName, children: currentCategoryName }),
          selectedModel && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "max-w-[150px] truncate rounded-md border border-primary/20 bg-primary/10 px-2 py-0.5 font-semibold text-primary flex items-center gap-1", title: selectedModel, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(OA, { className: "h-3 w-3 animate-pulse shrink-0" }),
            selectedModel
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-muted-foreground", children: [
            "(",
            filteredQuestions.length,
            " hasil)"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "overflow-hidden rounded-xl border border-border bg-card shadow-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full border-collapse text-left text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-b border-border bg-muted/70 text-[11px] font-semibold tracking-wider text-muted-foreground uppercase select-none", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "w-12 p-4 text-center", children: "ID" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "max-w-[250px] p-4", children: "Soal Evaluasi" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "hidden max-w-[200px] p-4 md:table-cell", children: "Struktur Breadcrumb" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "hidden w-[320px] p-4 lg:table-cell", children: "Pilihan Opsi" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "w-20 p-4 text-center", children: "Aksi" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { className: "divide-y divide-border", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { mode: "popLayout", children: paginatedQuestions.length > 0 ? paginatedQuestions.map((q) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.tr, { initial: {
            opacity: 0,
            y: 10
          }, animate: {
            opacity: 1,
            y: 0
          }, exit: {
            opacity: 0,
            x: -30
          }, transition: {
            duration: 0.2
          }, className: "group cursor-pointer transition-colors hover:bg-muted/30", onClick: () => setSelectedQuestion(q), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "p-4 text-center font-mono text-xs text-muted-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: q.id }),
              q.flagged_reason && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-0.5 rounded-full bg-red-500/10 px-1.5 py-0.5 text-[9px] font-bold text-red-600 shadow-3xs", title: `Masalah: ${q.flagged_reason}`, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(xi, { className: "h-2.5 w-2.5 shrink-0" }),
                "FLG"
              ] })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "max-w-[250px] p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "line-clamp-2 leading-relaxed font-medium text-foreground", title: q.question_text, children: q.question_text }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-1 flex flex-wrap items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1 text-[11px] text-muted-foreground", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx($C, { className: "h-3 w-3 text-emerald-600 shrink-0" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "max-w-[160px] truncate", title: q.article_title, children: q.article_title })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: async (e) => {
                  e.stopPropagation();
                  const newStatus = q.checked_status === "sudah dicek" ? "buatan AI" : "sudah dicek";
                  await toggleCheckedStatusFn({
                    data: {
                      id: q.id,
                      status: newStatus
                    }
                  });
                  await router.invalidate();
                }, className: `text-[9px] px-1.5 py-0.5 rounded font-semibold select-none cursor-pointer border transition-all duration-150 shrink-0 ${q.checked_status === "sudah dicek" ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/20 hover:bg-emerald-500/20" : "bg-indigo-500/10 text-indigo-600 border-indigo-500/20 hover:bg-indigo-500/20"}`, children: q.checked_status === "sudah dicek" ? "Sudah Dicek" : "Buatan AI" }),
                q.checked_status === "buatan AI" && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-0.5 rounded-full bg-primary/10 border border-primary/20 px-1.5 py-0.5 text-[9px] font-medium text-primary", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(OA, { className: "h-2.5 w-2.5 animate-pulse shrink-0" }),
                  q.created_by_model || "Gemini 2.5 Flash"
                ] })
              ] })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "vertical-align-middle hidden max-w-[200px] p-4 md:table-cell", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-1 overflow-hidden", children: [
              [...q.breadcrumbs].reverse().slice(0, 3).map((crumb, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-0.5 text-[10px]", children: [
                idx > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(J1, { className: "h-2.5 w-2.5 text-muted-foreground/60 shrink-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { onClick: (e) => {
                  e.stopPropagation();
                  setActiveFilterUrl(crumb.url === "https://ilmiyyah.com" ? null : crumb.url);
                }, className: "max-w-[100px] truncate rounded bg-muted px-1.5 py-0.5 font-medium text-muted-foreground transition-all hover:bg-primary/10 hover:text-primary cursor-pointer", title: crumb.title, children: crumb.title })
              ] }, idx)),
              q.breadcrumbs.length > 3 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "rounded bg-muted px-1 py-0.5 text-[9px] text-muted-foreground", children: [
                "+",
                q.breadcrumbs.length - 3
              ] })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "hidden max-w-[320px] p-4 text-xs lg:table-cell", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 gap-1.5", children: [{
              label: "A",
              val: q.option_a
            }, {
              label: "B",
              val: q.option_b
            }, {
              label: "C",
              val: q.option_c
            }, {
              label: "D",
              val: q.option_d
            }].map((opt) => {
              const isCorrect = q.correct_option.toUpperCase() === opt.label;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex items-center gap-1.5 truncate rounded-md border p-1 px-2 ${isCorrect ? "border-emerald-500/20 bg-emerald-500/10 font-medium text-emerald-700 dark:text-emerald-400" : "border-border bg-background text-muted-foreground/90"}`, title: `${opt.label}. ${opt.val}`, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-full text-[9px] font-semibold ${isCorrect ? "bg-emerald-500 text-white" : "bg-muted text-muted-foreground"}`, children: opt.label }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: opt.val })
              ] }, opt.label);
            }) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "p-4 text-center", onClick: (e) => e.stopPropagation(), children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "icon", className: "h-7 w-7 rounded-lg text-muted-foreground transition-all hover:bg-muted hover:text-primary cursor-pointer", onClick: () => setSelectedQuestion(q), title: "Analisis Detail", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ba, { className: "h-4 w-4" }) }),
              viewTab === "active" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative delete-popover-container inline-block", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "icon", className: "h-7 w-7 rounded-lg text-muted-foreground transition-all hover:bg-red-500/10 hover:text-red-600 cursor-pointer", onClick: () => setDeleteConfirmId({
                  id: q.id,
                  type: "soft"
                }), title: "Hapus Sementara", children: /* @__PURE__ */ jsxRuntimeExports.jsx(M6, { className: "h-4 w-4" }) }),
                deleteConfirmId?.id === q.id && deleteConfirmId?.type === "soft" && !deleteConfirmId.isInspector && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute right-0 bottom-full mb-2 z-50 w-56 rounded-xl border border-border bg-popover p-3 text-popover-foreground shadow-lg animate-in fade-in slide-in-from-bottom-2 duration-150", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 text-left", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-semibold text-xs text-foreground", children: "Hapus Sementara?" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-muted-foreground leading-relaxed", children: "Soal akan dipindahkan ke tab Sampah dan dapat dipulihkan kapan saja." }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-1.5 pt-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "ghost", className: "h-6 text-[10px] px-2 py-0.5", onClick: () => setDeleteConfirmId(null), children: "Batal" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", className: "h-6 text-[10px] px-2.5 py-0.5 bg-red-600 hover:bg-red-700 text-white font-medium animate-pulse", onClick: async () => {
                      await softDeleteQuestionFn({
                        data: q.id
                      });
                      setDeleteConfirmId(null);
                      await router.invalidate();
                    }, children: "Hapus" })
                  ] })
                ] }) })
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "icon", className: "h-7 w-7 rounded-lg text-muted-foreground transition-all hover:bg-emerald-500/10 hover:text-emerald-600 cursor-pointer", onClick: async () => {
                  await restoreQuestionFn({
                    data: q.id
                  });
                  await router.invalidate();
                }, title: "Pulihkan Soal", children: /* @__PURE__ */ jsxRuntimeExports.jsx(uo, { className: "h-4 w-4" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative delete-popover-container inline-block", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "icon", className: "h-7 w-7 rounded-lg text-muted-foreground transition-all hover:bg-red-600/15 hover:text-red-700 cursor-pointer", onClick: () => setDeleteConfirmId({
                    id: q.id,
                    type: "hard"
                  }), title: "Hapus Permanen", children: /* @__PURE__ */ jsxRuntimeExports.jsx(P7, { className: "h-4 w-4" }) }),
                  deleteConfirmId?.id === q.id && deleteConfirmId?.type === "hard" && !deleteConfirmId.isInspector && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute right-0 bottom-full mb-2 z-50 w-56 rounded-xl border border-red-500/20 bg-popover p-3 text-popover-foreground shadow-lg animate-in fade-in slide-in-from-bottom-2 duration-150", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 text-left", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "font-semibold text-xs text-red-600 flex items-center gap-1", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(y, { className: "h-3.5 w-3.5 animate-bounce" }),
                      "Hapus Permanen?"
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-muted-foreground leading-relaxed", children: "Tindakan ini tidak bisa dibatalkan. Soal akan dihapus selamanya." }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-1.5 pt-1", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "ghost", className: "h-6 text-[10px] px-2 py-0.5", onClick: () => setDeleteConfirmId(null), children: "Batal" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", className: "h-6 text-[10px] px-2.5 py-0.5 bg-red-600 hover:bg-red-700 text-white font-medium", onClick: async () => {
                        await hardDeleteQuestionFn({
                          data: q.id
                        });
                        setDeleteConfirmId(null);
                        await router.invalidate();
                      }, children: "Hapus" })
                    ] })
                  ] }) })
                ] })
              ] })
            ] }) })
          ] }, q.id)) : /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 5, className: "p-12 text-center text-muted-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx($C, { className: "h-8 w-8 animate-bounce text-muted-foreground/60" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium", children: "Tidak ada soal evaluasi ditemukan" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground/80", children: "Cobalah mereset pencarian atau filter silsilah kajian Anda." })
          ] }) }) }) }) })
        ] }) }),
        filteredQuestions.length > itemsPerPage && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-t border-border bg-muted/30 px-6 py-4 text-xs select-none", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-muted-foreground text-center sm:text-left", children: [
            "Menampilkan ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: (currentPage - 1) * itemsPerPage + 1 }),
            " - ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: Math.min(currentPage * itemsPerPage, filteredQuestions.length) }),
            " dari ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: filteredQuestions.length }),
            " soal"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-center gap-1.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", className: "h-8 rounded-lg px-3 py-1 cursor-pointer disabled:opacity-50 flex items-center gap-1", onClick: () => setCurrentPage((prev) => Math.max(prev - 1, 1)), disabled: currentPage === 1, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(J1, { className: "h-4 w-4 shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Sebelumnya" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1", children: Array.from({
              length: Math.ceil(filteredQuestions.length / itemsPerPage)
            }).map((_, idx) => {
              const pageNum = idx + 1;
              return /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setCurrentPage(pageNum), className: `flex h-8 w-8 items-center justify-center rounded-lg text-xs font-semibold transition-all cursor-pointer ${currentPage === pageNum ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground"}`, children: pageNum }, pageNum);
            }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", className: "h-8 rounded-lg px-3 py-1 cursor-pointer disabled:opacity-50 flex items-center gap-1", onClick: () => setCurrentPage((prev) => Math.min(prev + 1, Math.ceil(filteredQuestions.length / itemsPerPage))), disabled: currentPage === Math.ceil(filteredQuestions.length / itemsPerPage), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Berikutnya" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(r2, { className: "h-4 w-4 shrink-0" })
            ] })
          ] })
        ] })
      ] })
    ] }) }),
    selectedQuestion && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-background/60 backdrop-blur-xs select-none p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 cursor-pointer", onClick: closeInspector }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "animate-scaleIn relative flex max-h-[90vh] w-full max-w-2xl flex-col rounded-xl border border-border bg-card shadow-2xl overflow-hidden", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between border-b border-border bg-muted/30 p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(QM, { className: "h-5 w-5 text-primary" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-sm font-semibold text-foreground", children: [
              "Detail Analisis Soal #",
              selectedQuestion.id
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: closeInspector, className: "rounded-lg p-1.5 text-muted-foreground transition-all hover:bg-muted cursor-pointer", children: /* @__PURE__ */ jsxRuntimeExports.jsx(P7, { className: "h-5 w-5" }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1 overflow-y-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { mode: "wait", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
          opacity: 0,
          y: 15
        }, animate: {
          opacity: 1,
          y: 0
        }, exit: {
          opacity: 0,
          y: -15
        }, transition: {
          duration: 0.15
        }, className: "p-6 space-y-6", children: [
          selectedQuestion.deleted_at && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 rounded-lg border border-amber-500/20 bg-amber-500/10 p-3 text-xs text-amber-700 dark:text-amber-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(M6, { className: "h-4 w-4 shrink-0 text-amber-600" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold", children: "Soal ini berada di Tempat Sampah (Terarsipkan)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-0.5 text-[10px] text-amber-600/80", children: [
                "Dihapus pada: ",
                new Date(selectedQuestion.deleted_at).toLocaleString("id-ID")
              ] })
            ] })
          ] }),
          selectedQuestion.flagged_reason && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2 rounded-lg border border-red-500/20 bg-red-500/10 p-4 text-xs text-red-700 dark:text-red-400", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(xi, { className: "h-4.5 w-4.5 shrink-0 text-red-600 mt-0.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-red-800 dark:text-red-300", children: "Soal ini Ditandai / Bermasalah:" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-medium", children: [
                "Sebab: ",
                selectedQuestion.flagged_reason
              ] }),
              selectedQuestion.flagged_notes && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 border-t border-red-500/10 pt-1 text-red-700/80 italic", children: [
                "Saran/Catatan: “",
                selectedQuestion.flagged_notes,
                "”"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-[9px] text-red-500/70", children: [
                "Dilaporkan pada: ",
                selectedQuestion.flagged_at ? new Date(selectedQuestion.flagged_at).toLocaleString("id-ID") : "-"
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1 text-[10px] font-semibold tracking-wider text-muted-foreground uppercase", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(hs, { className: "h-3.5 w-3.5" }),
              "Struktur Materi"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap items-center gap-1 rounded-lg border border-border bg-muted/40 p-2.5 text-xs leading-normal", children: [...selectedQuestion.breadcrumbs].reverse().map((crumb, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
              idx > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(J1, { className: "h-3 w-3 text-muted-foreground/60 shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { onClick: () => {
                setActiveFilterUrl(crumb.url === "https://ilmiyyah.com" ? null : crumb.url);
                closeInspector();
              }, className: "font-medium text-muted-foreground/90 rounded bg-muted/60 px-1.5 py-0.5 hover:bg-primary/10 hover:text-primary transition-colors cursor-pointer", children: crumb.title })
            ] }, idx)) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-semibold tracking-wider text-muted-foreground uppercase", children: "Pertanyaan" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-xl border border-primary/10 bg-primary/5 p-4 text-sm leading-relaxed font-semibold text-foreground", children: selectedQuestion.question_text })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1 text-[10px] font-semibold tracking-wider text-muted-foreground uppercase", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(c4, { className: "h-3.5 w-3.5 text-primary" }),
              "Kutipan Rujukan Verbatim (Ayat / Hadits / Teks Kajian)"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-primary/20 bg-primary/5 p-4 text-xs italic leading-relaxed text-foreground/90 relative", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute top-2 right-3 font-serif text-3xl text-primary/20 select-none", children: "“" }),
              selectedQuestion.reference_snippet || "Tidak ada kutipan verbatim rujukan yang tersedia."
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-semibold tracking-wider text-muted-foreground uppercase", children: "Pilihan Jawaban" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 text-xs", children: [{
              label: "A",
              val: selectedQuestion.option_a
            }, {
              label: "B",
              val: selectedQuestion.option_b
            }, {
              label: "C",
              val: selectedQuestion.option_c
            }, {
              label: "D",
              val: selectedQuestion.option_d
            }].map((opt) => {
              const isCorrect = selectedQuestion.correct_option.toUpperCase() === opt.label;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex items-start gap-3 rounded-lg border p-3 transition-all ${isCorrect ? "border-emerald-500/20 bg-emerald-500/10 font-medium text-emerald-800 shadow-2xs dark:text-emerald-400" : "border-border bg-card text-muted-foreground"}`, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10px] font-bold ${isCorrect ? "bg-emerald-500 text-white" : "bg-muted text-muted-foreground"}`, children: opt.label }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "leading-relaxed", children: opt.val }),
                isCorrect && /* @__PURE__ */ jsxRuntimeExports.jsx(s7, { className: "ml-auto h-4 w-4 shrink-0 self-center text-emerald-600" })
              ] }, opt.label);
            }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1 text-[10px] font-semibold tracking-wider text-muted-foreground uppercase", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ba, { className: "h-3.5 w-3.5" }),
              "Keterangan & Penjelasan Ilmiah"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-xl border border-border bg-card p-4 text-xs leading-relaxed text-muted-foreground", children: selectedQuestion.explanation || "Tidak ada penjelasan tambahan yang tersedia." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] font-semibold tracking-wider text-muted-foreground uppercase", children: "Sumber Rujukan Kajian" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 rounded-xl border border-border bg-muted/40 p-4 text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 border-b border-border/60 pb-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Judul Artikel:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "max-w-[250px] truncate font-semibold text-foreground", title: selectedQuestion.article_title, children: selectedQuestion.article_title })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 border-b border-border/60 pb-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Pembicara:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: selectedQuestion.article_speaker })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 border-b border-border/60 pb-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Silsilah:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "max-w-[250px] truncate font-semibold text-foreground", children: selectedQuestion.article_silsilah || "-" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 pt-1 text-[11px]", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Tautan Web:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: selectedQuestion.article_url, target: "_blank", rel: "noopener noreferrer", className: "flex max-w-[280px] items-center gap-0.5 truncate font-medium text-primary hover:underline", children: [
                  selectedQuestion.article_url.replace("https://", ""),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(i2, { className: "h-3 w-3" })
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1 text-[10px] font-semibold tracking-wider text-muted-foreground uppercase", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(uo, { className: "h-3.5 w-3.5" }),
              "Audit Log & Riwayat Soal"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 rounded-xl border border-border bg-muted/40 p-4 text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 border-b border-border/60 pb-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Status Verifikasi:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: async () => {
                  const newStatus = selectedQuestion.checked_status === "sudah dicek" ? "buatan AI" : "sudah dicek";
                  await toggleCheckedStatusFn({
                    data: {
                      id: selectedQuestion.id,
                      status: newStatus
                    }
                  });
                  await router.invalidate();
                }, className: `text-[9px] px-2 py-0.5 rounded font-semibold select-none cursor-pointer border transition-all duration-150 shrink-0 ${selectedQuestion.checked_status === "sudah dicek" ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/20 hover:bg-emerald-500/20" : "bg-indigo-500/10 text-indigo-600 border-indigo-500/20 hover:bg-indigo-500/20"}`, children: selectedQuestion.checked_status === "sudah dicek" ? "Sudah Dicek" : "Buatan AI" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 border-b border-border/60 pb-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Pembuat (AI Model):" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-semibold text-foreground flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(OA, { className: "h-3 w-3 text-primary animate-pulse" }),
                  selectedQuestion.created_by_model || "Gemini 2.5 Flash"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 border-b border-border/60 pb-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Perangkat Pembuat:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: selectedQuestion.created_on_device || "Server-Prod-01" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 border-b border-border/60 pb-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Pengubah Terakhir:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: selectedQuestion.updated_by_model || "-" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 border-b border-border/60 pb-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Perangkat Pengubah:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: selectedQuestion.updated_on_device || "-" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 pt-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Terakhir Diperbarui:" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-foreground", children: selectedQuestion.updated_at ? new Date(selectedQuestion.updated_at).toLocaleString("id-ID") : "-" })
              ] })
            ] })
          ] })
        ] }, selectedQuestion.id) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center border-t border-border bg-muted/30 p-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-2", children: selectedQuestion.deleted_at ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: async () => {
              const nextQuestion = hasNext ? filteredQuestions[currentIndex + 1] : hasPrevious ? filteredQuestions[currentIndex - 1] : null;
              await restoreQuestionFn({
                data: selectedQuestion.id
              });
              await router.invalidate();
              if (nextQuestion) {
                setSelectedQuestion(nextQuestion);
              } else {
                closeInspector();
              }
            }, className: "bg-emerald-600 hover:bg-emerald-700 text-white text-xs px-3.5 py-1.5 font-medium rounded-lg cursor-pointer", children: "Pulihkan Soal" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative delete-popover-container inline-block", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: () => setDeleteConfirmId({
                id: selectedQuestion.id,
                type: "hard",
                isInspector: true
              }), className: "bg-red-700 hover:bg-red-800 text-white text-xs px-3.5 py-1.5 font-medium rounded-lg cursor-pointer", children: "Hapus Permanen" }),
              deleteConfirmId?.id === selectedQuestion.id && deleteConfirmId?.type === "hard" && deleteConfirmId.isInspector && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute left-0 bottom-full mb-2 z-50 w-64 rounded-xl border border-red-500/20 bg-popover p-4 text-popover-foreground shadow-xl animate-in fade-in slide-in-from-bottom-2 duration-150", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 text-left", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "font-semibold text-xs text-red-600 flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(y, { className: "h-4 w-4 animate-bounce text-red-500" }),
                  "Hapus Soal Permanen?"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-muted-foreground leading-relaxed", children: "Tindakan ini tidak bisa dibatalkan. Soal ini akan dihapus selamanya dari database." }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-1.5 pt-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "ghost", className: "h-6 text-[10px] px-2 py-0.5", onClick: () => setDeleteConfirmId(null), children: "Batal" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", className: "h-6 text-[10px] px-2.5 py-0.5 bg-red-600 hover:bg-red-700 text-white font-medium", onClick: async () => {
                    const nextQuestion = hasNext ? filteredQuestions[currentIndex + 1] : hasPrevious ? filteredQuestions[currentIndex - 1] : null;
                    await hardDeleteQuestionFn({
                      data: selectedQuestion.id
                    });
                    setDeleteConfirmId(null);
                    await router.invalidate();
                    if (nextQuestion) {
                      setSelectedQuestion(nextQuestion);
                    } else {
                      closeInspector();
                    }
                  }, children: "Hapus" })
                ] })
              ] }) })
            ] })
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative delete-popover-container inline-block", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: () => setDeleteConfirmId({
                id: selectedQuestion.id,
                type: "soft",
                isInspector: true
              }), className: "bg-red-500/10 hover:bg-red-500/20 text-red-600 text-xs px-3.5 py-1.5 font-medium rounded-lg border border-red-500/20 cursor-pointer", children: "Arsipkan Soal" }),
              deleteConfirmId?.id === selectedQuestion.id && deleteConfirmId?.type === "soft" && deleteConfirmId.isInspector && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute left-0 bottom-full mb-2 z-50 w-64 rounded-xl border border-border bg-popover p-4 text-popover-foreground shadow-xl animate-in fade-in slide-in-from-bottom-2 duration-150", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 text-left", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "font-semibold text-xs text-foreground flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(y, { className: "h-4 w-4 text-red-500" }),
                  "Arsipkan Soal?"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-muted-foreground leading-relaxed", children: "Soal akan dipindahkan ke tab Sampah dan dapat dipulihkan kapan saja." }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-1.5 pt-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "ghost", className: "h-6 text-[10px] px-2 py-0.5", onClick: () => setDeleteConfirmId(null), children: "Batal" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", className: "h-6 text-[10px] px-2.5 py-0.5 bg-red-600 hover:bg-red-700 text-white font-medium animate-pulse", onClick: async () => {
                    const nextQuestion = hasNext ? filteredQuestions[currentIndex + 1] : hasPrevious ? filteredQuestions[currentIndex - 1] : null;
                    await softDeleteQuestionFn({
                      data: selectedQuestion.id
                    });
                    setDeleteConfirmId(null);
                    await router.invalidate();
                    if (nextQuestion) {
                      setSelectedQuestion(nextQuestion);
                    } else {
                      closeInspector();
                    }
                  }, children: "Arsipkan" })
                ] })
              ] }) })
            ] }),
            selectedQuestion.flagged_reason ? /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: async () => {
              if (confirm("Selesaikan bendera masalah untuk soal ini? Soal akan ditandai kembali sebagai normal.")) {
                const nextQuestion = hasNext ? filteredQuestions[currentIndex + 1] : hasPrevious ? filteredQuestions[currentIndex - 1] : null;
                await resolveQuestionFn({
                  data: selectedQuestion.id
                });
                await router.invalidate();
                if (nextQuestion) {
                  setSelectedQuestion(nextQuestion);
                } else {
                  closeInspector();
                }
              }
            }, className: "bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-600 text-xs px-3.5 py-1.5 font-medium rounded-lg border border-emerald-500/20 cursor-pointer", children: "Selesaikan Masalah" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: () => setIsFlagModalOpen(true), className: "bg-amber-500/10 hover:bg-amber-500/20 text-amber-600 text-xs px-3.5 py-1.5 font-medium rounded-lg border border-amber-500/20 cursor-pointer", children: "Tandai Masalah" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { disabled: !hasPrevious, onClick: () => setSelectedQuestion(filteredQuestions[currentIndex - 1]), className: "bg-muted border border-border hover:bg-muted-foreground/10 text-foreground text-xs px-3.5 py-1.5 font-medium rounded-lg disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer shadow-3xs", children: "Sebelumnya" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { disabled: !hasNext, onClick: () => setSelectedQuestion(filteredQuestions[currentIndex + 1]), className: "bg-primary text-primary-foreground hover:bg-primary/95 text-xs px-3.5 py-1.5 font-medium rounded-lg disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer shadow-3xs", children: "Selanjutnya" })
          ] })
        ] })
      ] })
    ] }),
    isFilterModalOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-background/60 backdrop-blur-xs select-none", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 cursor-pointer", onClick: () => setIsFilterModalOpen(false) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "animate-scaleIn relative flex max-h-[85vh] w-full max-w-lg flex-col rounded-xl border border-border bg-card shadow-2xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between border-b border-border bg-muted/30 p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(hs, { className: "h-5 w-5 text-primary" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold text-foreground", children: "Pilih Silsilah / Materi Kajian" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setIsFilterModalOpen(false), className: "rounded-lg p-1.5 text-muted-foreground transition-all hover:bg-muted cursor-pointer", children: /* @__PURE__ */ jsxRuntimeExports.jsx(P7, { className: "h-5 w-5" }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto p-6 space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Pilih silsilah materi untuk menyaring soal evaluasi di bawah. Klik ikon panah untuk memperluas bab." }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-lg border border-border bg-background/50 p-3 max-h-[50vh] overflow-y-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsx(HierarchyFolderTree, { node: folderTree, activeFilter: activeFilterUrl, onSelectNode: (url) => {
            setActiveFilterUrl(url);
            setIsFilterModalOpen(false);
          }, expandedNodes, toggleExpand }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center border-t border-border bg-muted/30 p-4", children: [
          activeFilterUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", onClick: () => {
            setActiveFilterUrl(null);
            setIsFilterModalOpen(false);
          }, className: "text-xs text-red-600 hover:text-red-700 hover:bg-red-500/10 cursor-pointer", children: "Reset Filter" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", {}),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: () => setIsFilterModalOpen(false), className: "bg-primary text-primary-foreground hover:bg-primary/95 text-xs px-4 py-1.5 rounded-lg cursor-pointer", children: "Tutup" })
        ] })
      ] })
    ] }),
    isFlagModalOpen && selectedQuestion && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-background/60 backdrop-blur-xs select-none", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 cursor-pointer", onClick: () => setIsFlagModalOpen(false) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "animate-scaleIn relative flex max-h-[85vh] w-full max-w-md flex-col rounded-xl border border-border bg-card shadow-2xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between border-b border-border bg-muted/30 p-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(vi, { className: "h-5 w-5 text-red-600 animate-pulse" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-sm font-semibold text-foreground", children: [
              "Tandai Masalah (Soal #",
              selectedQuestion.id,
              ")"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setIsFlagModalOpen(false), className: "rounded-lg p-1.5 text-muted-foreground transition-all hover:bg-muted cursor-pointer", children: /* @__PURE__ */ jsxRuntimeExports.jsx(P7, { className: "h-5 w-5" }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 overflow-y-auto p-6 space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg border border-red-500/10 bg-red-500/5 p-3 text-xs text-red-700 dark:text-red-400 leading-relaxed font-medium", children: [
            "Soal: “",
            selectedQuestion.question_text,
            "”"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-semibold text-muted-foreground uppercase block", children: "Kategori Masalah" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 gap-2 text-xs", children: ["Pertanyaan tidak jelas/bias", "Jawaban Salah", "Pilihan Jawaban Salah ada yang juga benar", "Keterangan tidak ada hubungannya", "Keterangan tidak ada di artikel", "Lainnya"].map((reason) => /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 cursor-pointer rounded-lg border border-border bg-card p-2 hover:bg-muted/40 transition-colors", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "radio", name: "flag_reason_modal", checked: flagReason === reason, onChange: () => setFlagReason(reason), className: "text-primary focus:ring-primary h-3.5 w-3.5 cursor-pointer" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground", children: reason })
            ] }, reason)) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-[10px] font-semibold text-muted-foreground uppercase block", children: "Catatan Perbaikan / Saran Lainnya" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("textarea", { value: flagNotes, onChange: (e) => setFlagNotes(e.target.value), placeholder: "Tuliskan detail perbaikan atau saran Anda di sini...", className: "w-full min-h-[80px] rounded-lg border border-border bg-background p-3 text-xs focus:ring-1 focus:ring-primary focus:border-primary outline-none text-foreground" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-2 border-t border-border bg-muted/30 p-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", onClick: () => setIsFlagModalOpen(false), className: "h-8 text-xs cursor-pointer", children: "Batal" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: async () => {
            await flagQuestionFn({
              data: {
                id: selectedQuestion.id,
                reason: flagReason,
                notes: flagNotes
              }
            });
            setFlagNotes("");
            await router.invalidate();
            if (hasNext) {
              setSelectedQuestion(filteredQuestions[currentIndex + 1]);
            } else {
              setIsFlagModalOpen(false);
              closeInspector();
            }
          }, className: "h-8 bg-red-600 hover:bg-red-700 text-white text-xs px-4 rounded-lg font-medium cursor-pointer", children: "Kirim Laporan" })
        ] })
      ] })
    ] })
  ] });
}
export {
  SemuaDashboard as component
};
