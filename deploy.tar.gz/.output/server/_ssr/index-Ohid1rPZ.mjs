import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { B as Button } from "./button-DLuSCGEG.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
function App() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-svh p-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex max-w-md min-w-0 flex-col gap-4 text-sm leading-loose", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-medium", children: "Project ready!" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "You may now add components and start building." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "We've already added the button component for you." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { className: "mt-2", children: "Button" })
  ] }) }) });
}
export {
  App as component
};
